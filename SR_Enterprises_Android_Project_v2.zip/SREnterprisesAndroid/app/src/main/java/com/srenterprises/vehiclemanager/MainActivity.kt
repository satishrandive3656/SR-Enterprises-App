package com.srenterprises.vehiclemanager

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class VehicleRow(val id: Long, val type: String, val number: String, val driver: String, val inTime: String, val outTime: String)
data class DieselRow(val id: Long, val number: String, val litres: Double, val time: String, val note: String)

class AppDb(context: Context) : SQLiteOpenHelper(context, "sr_enterprises.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE vehicles(id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, number TEXT, driver TEXT, intime TEXT, outtime TEXT)")
        db.execSQL("CREATE TABLE diesel(id INTEGER PRIMARY KEY AUTOINCREMENT, number TEXT, litres REAL, time TEXT, note TEXT)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun addVehicle(type:String, number:String, driver:String, inside:String, outside:String) {
        val v=ContentValues().apply { put("type",type);put("number",number);put("driver",driver);put("intime",inside);put("outtime",outside) }
        writableDatabase.insert("vehicles",null,v)
    }
    fun addDiesel(number:String, litres:Double, time:String, note:String) {
        val v=ContentValues().apply { put("number",number);put("litres",litres);put("time",time);put("note",note) }
        writableDatabase.insert("diesel",null,v)
    }
    fun vehicles():List<VehicleRow> {
        val out=mutableListOf<VehicleRow>()
        readableDatabase.rawQuery("SELECT * FROM vehicles ORDER BY id DESC",null).use { c ->
            while(c.moveToNext()) out.add(VehicleRow(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5)))
        }; return out
    }
    fun diesels():List<DieselRow> {
        val out=mutableListOf<DieselRow>()
        readableDatabase.rawQuery("SELECT * FROM diesel ORDER BY id DESC",null).use { c ->
            while(c.moveToNext()) out.add(DieselRow(c.getLong(0),c.getString(1),c.getDouble(2),c.getString(3),c.getString(4)))
        }; return out
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db=AppDb(this)
        val prefs=getSharedPreferences("sr_lock", MODE_PRIVATE)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF1769AA))) {
            Surface(Modifier.fillMaxSize()) { AppScreen(db, prefs) }
        } }
    }
}

fun nowText():String = SimpleDateFormat("dd-MM-yyyy hh:mm a", Locale("mr","IN")).format(Date())
fun digest(s:String):String = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

@Composable
fun AppScreen(db:AppDb, prefs:android.content.SharedPreferences) {
    val ctx= LocalContext.current
    var unlocked by remember { mutableStateOf(prefs.getString("pin_hash", null)==null) }
    var pin by remember { mutableStateOf("") }
    var setup by remember { mutableStateOf(prefs.getString("pin_hash", null)==null) }
    var error by remember { mutableStateOf("") }
    if (!unlocked) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement=Arrangement.Center) {
            Text("SR ENTERPRISES", style=MaterialTheme.typography.headlineMedium, fontWeight=FontWeight.Bold)
            Text("ॲप लॉक")
            OutlinedTextField(pin,{ if(it.length<=4 && it.all(Char::isDigit)) pin=it },label={Text("४ अंकी PIN")},visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword))
            if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error)
            Button(onClick={ if(pin.length==4 && digest(pin)==prefs.getString("pin_hash","")) {unlocked=true;pin=""} else error="PIN चुकीचा आहे." }) { Text("ॲप उघडा") }
        }
        return
    }
    if (setup) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement=Arrangement.Center) {
            Text("SR ENTERPRISES", style=MaterialTheme.typography.headlineMedium, fontWeight=FontWeight.Bold)
            Text("पहिल्यांदा ४ अंकी PIN सेट करा.")
            OutlinedTextField(pin,{if(it.length<=4 && it.all(Char::isDigit)) pin=it},label={Text("नवीन PIN")},visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword))
            Button(onClick={ if(pin.length==4){prefs.edit().putString("pin_hash",digest(pin)).apply();setup=false;pin="";Toast.makeText(ctx,"PIN सेट झाला",Toast.LENGTH_SHORT).show()} else error="४ अंकांचा PIN टाका." }) { Text("PIN सेव्ह करा") }
            if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error)
        }
        return
    }
    var tab by remember { mutableStateOf(0) }
    var refresh by remember { mutableIntStateOf(0) }
    val vehicles= remember(refresh) { db.vehicles() }
    val diesels= remember(refresh) { db.diesels() }
    Scaffold(topBar={ TopAppBarCompat() }, bottomBar={
        NavigationBar {
            NavigationBarItem(selected=tab==0,onClick={tab=0},icon={Text("🚛")},label={Text("गाडी नोंद")})
            NavigationBarItem(selected=tab==1,onClick={tab=1},icon={Text("⛽")},label={Text("डिझेल")})
            NavigationBarItem(selected=tab==2,onClick={tab=2},icon={Text("📋")},label={Text("रिपोर्ट")})
        }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            when(tab) {
                0 -> VehicleForm(onSave={t,n,d,i,o -> db.addVehicle(t,n,d,i,o);refresh++;Toast.makeText(ctx,"गाडीची नोंद जतन झाली",Toast.LENGTH_SHORT).show()})
                1 -> DieselForm(onSave={n,l,t,note -> db.addDiesel(n,l,t,note);refresh++;Toast.makeText(ctx,"डिझेलची नोंद जतन झाली",Toast.LENGTH_SHORT).show()})
                else -> {
                    Text("एकूण गाडी नोंदी: ${vehicles.size}",style=MaterialTheme.typography.titleMedium)
                    Text("एकूण डिझेल: ${"%.1f".format(diesels.sumOf{it.litres})} लिटर",style=MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(12.dp)); Text("गाडीच्या नोंदी",fontWeight=FontWeight.Bold)
                    vehicles.forEach { Text("${it.number} • ${it.type}\nIN: ${it.inTime}   OUT: ${it.outTime.ifBlank{"बाकी"}}",Modifier.padding(vertical=6.dp)) }
                    Spacer(Modifier.height(12.dp)); Text("डिझेलच्या नोंदी",fontWeight=FontWeight.Bold)
                    diesels.forEach { Text("${it.number} • ${it.litres} लिटर • ${it.time}",Modifier.padding(vertical=6.dp)) }
                    OutlinedButton(onClick={prefs.edit().remove("pin_hash").apply();setup=true;unlocked=true;pin=""}) { Text("PIN बदलण्यासाठी लॉक रीसेट करा") }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun TopAppBarCompat() {
    TopAppBar(title={Column { Text("SR ENTERPRISES",fontWeight=FontWeight.Bold);Text("गाडी व डिझेल व्यवस्थापन",style=MaterialTheme.typography.labelSmall) }})
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VehicleForm(onSave:(String,String,String,String,String)->Unit) {
    var type by remember { mutableStateOf("पोकलेन") }; var number by remember { mutableStateOf("") }; var driver by remember { mutableStateOf("") }
    var inside by remember { mutableStateOf(nowText()) }; var outside by remember { mutableStateOf("") }
    val types=listOf("पोकलेन","JCB","डंपर / हायवा","ट्रॅक्टर","ट्रक","इतर")
    Text("नवीन गाडीची नोंद",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=it}) {
        OutlinedTextField(value=type,onValueChange={},modifier=Modifier.menuAnchor(),readOnly=true,label={Text("गाडीचा प्रकार")},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded)})
        ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) { types.forEach { DropdownMenuItem(text={Text(it)},onClick={type=it;expanded=false}) } }
    }
    Field("गाडी नंबर",number,{number=it});Field("ड्रायव्हरचे नाव",driver,{driver=it})
    Field("IN वेळ (मॅन्युअल)",inside,{inside=it});Button(onClick={inside=nowText()},modifier=Modifier.fillMaxWidth()){Text("आत्ताची IN वेळ भरा")}
    Field("OUT वेळ (मॅन्युअल)",outside,{outside=it});Button(onClick={outside=nowText()},modifier=Modifier.fillMaxWidth()){Text("आत्ताची OUT वेळ भरा")}
    Button(onClick={if(number.isNotBlank()) onSave(type,number.trim().uppercase(),driver,inside,outside) },modifier=Modifier.fillMaxWidth()) { Text("गाडीची नोंद जतन करा") }
    Text("नोंदी या मोबाईलमध्ये ऑफलाइन जतन होतात.",style=MaterialTheme.typography.bodySmall)
}

@Composable
fun DieselForm(onSave:(String,Double,String,String)->Unit) {
    var number by remember { mutableStateOf("") };var litres by remember { mutableStateOf("") };var time by remember { mutableStateOf(nowText()) };var note by remember { mutableStateOf("") }
    Text("डिझेलची नोंद",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
    Field("गाडी नंबर",number,{number=it});Field("डिझेल (लिटर)",litres,{litres=it},true);Field("वेळ (मॅन्युअल)",time,{time=it})
    Button(onClick={time=nowText()},modifier=Modifier.fillMaxWidth()){Text("आत्ताची वेळ भरा")}
    Field("नोंद / टिप",note,{note=it})
    Button(onClick={val l=litres.toDoubleOrNull();if(number.isNotBlank() && l!=null && l>0) onSave(number.trim().uppercase(),l,time,note)},modifier=Modifier.fillMaxWidth()){Text("डिझेल नोंद जतन करा")}
    Text("एका गाडीला अनेक वेळा डिझेल नोंदवता येईल.",style=MaterialTheme.typography.bodySmall)
}

@Composable
fun Field(label:String,value:String,onChange:(String)->Unit,numeric:Boolean=false) {
    OutlinedTextField(value,onChange,modifier=Modifier.fillMaxWidth().padding(vertical=4.dp),label={Text(label)},singleLine=true,
        keyboardOptions=if(numeric) KeyboardOptions(keyboardType=KeyboardType.Decimal) else KeyboardOptions.Default)
}
