# SR Enterprises – Vehicle Management (Android source)

हा Android Studio प्रोजेक्ट आहे. यामध्ये मराठी UI, PIN सेटअप/लॉक, ऑफलाइन SQLite डेटाबेस, गाडी IN/OUT, मॅन्युअल/आत्ताची वेळ, अनेक डिझेल नोंदी आणि रिपोर्ट स्क्रीन आहे.

## AAB कसा तयार करायचा
1. संगणकावर Android Studio (JDK 17 सह) इन्स्टॉल करा.
2. हा प्रोजेक्ट Android Studio मध्ये Open करा.
3. Gradle Sync पूर्ण होऊ द्या.
4. Build > Generate Signed Bundle / APK > Android App Bundle निवडा.
5. नवीन upload key तयार करून सुरक्षित ठेवा आणि release AAB तयार करा.
6. Google Play Console मध्ये AAB अपलोड करा.

## महत्त्वाच्या मर्यादा
- हा source project आहे; compiled APK/AAB नाही.
- या वातावरणात Android SDK/Gradle build आणि device testing केलेले नाही.
- Play Store साठी privacy policy, app content/data safety, store listing, screenshots, developer verification आणि लागू असल्यास closed testing आवश्यक असू शकते.
- PIN विसरल्यास सध्या अॅपमधील डेटा पुसून पुन्हा सेटअप करण्याची प्रक्रिया लागू शकते; PIN सुरक्षित ठेवा.
- डेटा फोनमध्येच राहतो. फोन हरवल्यास किंवा अॅप डेटा हटवल्यास नोंदी जाऊ शकतात. भविष्यात backup/export जोडणे आवश्यक आहे.
